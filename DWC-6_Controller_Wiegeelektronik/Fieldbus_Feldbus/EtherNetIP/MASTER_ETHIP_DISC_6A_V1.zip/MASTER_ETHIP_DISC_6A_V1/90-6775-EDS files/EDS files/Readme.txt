EDS files for the Anybus-IC EtherNet/IP module


EDS file used with firmware versions 3.07 uses a new naming convention, the file name have following syntax.

005A000C00020300 = 005A Vendor ID (HMS Industrial Networks), 000C Device type (Communication Adapter), 0002 Product Code (Anybus-IC EtherNet/IP) and 0300 Major Revison. 


EDS files:

005A000C00020300.eds used with firmware version 3.07

EDS_ABIC_EIP_V_3_0.eds used with firmware version up to 3.02

EDS_ABIC_EIP_V_2_1.eds used with firmware version up to 2.04

EDS_ABIC_EIP_V_1_7.eds used with firmware version up to 1.08