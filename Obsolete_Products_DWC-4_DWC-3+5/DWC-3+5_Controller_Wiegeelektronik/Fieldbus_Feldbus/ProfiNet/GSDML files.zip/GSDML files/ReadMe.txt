GSDML files for the Anybus-S ProfiNet IRT module.

GSDML-V2.2-Hms-ABSPIR-20091118.xml used to the module with FW version 2.x.

